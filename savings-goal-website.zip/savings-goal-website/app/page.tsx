'use client';
import { FormEvent, useEffect, useMemo, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import { getSupabase } from '../lib/supabase';

type Goal = { id: string; user_id: string; title: string; target_amount: number; current_amount: number; monthly_saving: number; created_at: string };
const money = (n: number) => new Intl.NumberFormat('th-TH', { maximumFractionDigits: 0 }).format(n) + ' บาท';

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [isError, setIsError] = useState(false);
  const [authMode, setAuthMode] = useState<'login'|'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [title, setTitle] = useState('เป้าหมายเงินเก็บของเรา');
  const [target, setTarget] = useState(100000);
  const [current, setCurrent] = useState(0);
  const [monthly, setMonthly] = useState(2000);
  const [editing, setEditing] = useState<string | null>(null);
  const supabase = useMemo(() => { try { return getSupabase(); } catch { return null; } }, []);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setUser(data.session?.user ?? null); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setUser(session?.user ?? null); });
    return () => listener.subscription.unsubscribe();
  }, [supabase]);
  useEffect(() => { if (user && supabase) void loadGoals(); }, [user, supabase]);

  async function loadGoals() {
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.from('savings_goals').select('*').order('created_at', { ascending: false });
    if (error) show(error.message, true); else setGoals((data ?? []) as Goal[]);
    setLoading(false);
  }
  function show(text: string, error = false) { setMessage(text); setIsError(error); }
  async function handleAuth(e: FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage('');
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) show(result.error.message, true);
    else if (authMode === 'signup' && !result.data.session) show('สมัครแล้ว กรุณาตรวจอีเมลเพื่อยืนยันบัญชี ก่อนเข้าสู่ระบบ');
    else { setUser(result.data.user); show(authMode === 'signup' ? 'สมัครสมาชิกสำเร็จ' : 'เข้าสู่ระบบสำเร็จ'); }
  }
  function resetForm() { setTitle('เป้าหมายเงินเก็บของเรา'); setTarget(100000); setCurrent(0); setMonthly(2000); setEditing(null); }
  async function saveGoal(e: FormEvent) {
    e.preventDefault(); if (!supabase || !user) return;
    if (!title.trim()) return show('กรุณาตั้งชื่อเป้าหมาย', true);
    if (target < 0 || target > 1000000 || current < 0 || current > 1000000 || monthly < 0 || monthly > 100000) return show('กรุณาตรวจสอบจำนวนเงินตามช่วงที่กำหนด', true);
    setBusy(true); setMessage('');
    const row = { title: title.trim(), target_amount: target, current_amount: current, monthly_saving: monthly, user_id: user.id };
    const result = editing
      ? await supabase.from('savings_goals').update(row).eq('id', editing).select().single()
      : await supabase.from('savings_goals').insert(row).select().single();
    setBusy(false);
    if (result.error) show(result.error.message, true);
    else { show(editing ? 'แก้ไขเป้าหมายแล้ว' : 'บันทึกเป้าหมายแล้ว'); resetForm(); await loadGoals(); }
  }
  async function deleteGoal(id: string) {
    if (!supabase || !window.confirm('ต้องการลบเป้าหมายนี้หรือไม่?')) return;
    const { error } = await supabase.from('savings_goals').delete().eq('id', id);
    if (error) show(error.message, true); else { show('ลบเป้าหมายแล้ว'); await loadGoals(); }
  }
  function editGoal(g: Goal) { setEditing(g.id); setTitle(g.title); setTarget(g.target_amount); setCurrent(g.current_amount); setMonthly(g.monthly_saving); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  async function signOut() { if (supabase) await supabase.auth.signOut(); setUser(null); setGoals([]); resetForm(); }

  if (!supabase) return <main className="page"><header className="hero"><h1>🎯 เป้าหมายเงินเก็บของเรา</h1><p>วางแผนวันนี้ เพื่ออนาคตที่มั่นคงกว่า</p></header><section className="card"><h2 className="sectiontitle">ต้องตั้งค่าก่อนเริ่มใช้งาน</h2><p>ยังไม่พบการตั้งค่า Supabase กรุณาทำตามคู่มือในไฟล์ README.md โดยสร้างไฟล์ <code>.env.local</code> จาก <code>.env.example</code> แล้วใส่ URL และ publishable/anon key ของโปรเจกต์</p><div className="notice">อย่าใส่ service_role key ลงในเว็บไซต์หรือไฟล์ที่ขึ้นต้นด้วย NEXT_PUBLIC_ เด็ดขาด</div></section></main>;
  if (loading && !user) return <main className="page"><div className="empty">กำลังโหลด…</div></main>;
  if (!user) return <main className="auth"><header className="hero"><h1>🎯 เป้าหมายเงินเก็บของเรา</h1><p>บันทึกเป้าหมายของคุณอย่างเป็นระบบ</p></header><section className="card"><div className="actions"><button className={'btn '+(authMode==='signup'?'':'secondary')} onClick={()=>{setAuthMode('signup');setMessage('')}}>สมัครสมาชิก</button><button className={'btn '+(authMode==='login'?'':'secondary')} onClick={()=>{setAuthMode('login');setMessage('')}}>เข้าสู่ระบบ</button></div><h2 className="sectiontitle" style={{marginTop:18}}>{authMode==='signup'?'สร้างบัญชีใหม่':'ยินดีต้อนรับกลับ'}</h2><p className="sub">ข้อมูลเป้าหมายจะถูกบันทึกในบัญชีของคุณ</p><form onSubmit={handleAuth}><div className="field"><label>อีเมล</label><input type="email" required autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" /></div><div className="field"><label>รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)</label><input type="password" required minLength={8} autoComplete={authMode==='signup'?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" /></div><button className="btn" disabled={busy} type="submit">{busy?'กำลังดำเนินการ…':authMode==='signup'?'สมัครสมาชิก':'เข้าสู่ระบบ'}</button></form>{message&&<div className={'notice '+(isError?'error':'success')}>{message}</div>}</section><p className="footer">ข้อมูลของแต่ละบัญชีแยกจากกันด้วยสิทธิ์ในฐานข้อมูล</p></main>;

  const remaining = Math.max(0, target-current);
  const months = remaining === 0 ? 0 : monthly > 0 ? Math.ceil(remaining/monthly) : null;
  const progress = target > 0 ? Math.min(100, current/target*100) : 100;
  return <main className="page"><div className="topline"><div className="userline">เข้าสู่ระบบด้วย {user.email}</div><div className="actions"><a className="btn secondary" href="/admin" style={{textDecoration:'none'}}>หลังบ้าน</a><button className="btn secondary" onClick={signOut}>ออกจากระบบ</button></div></div><header className="hero"><h1>🎯 เป้าหมายเงินเก็บของเรา</h1><p>วางแผนเล็ก ๆ อย่างสม่ำเสมอ เพื่อเป้าหมายที่ใหญ่ขึ้น</p></header>
  <div className="grid"><section className="card"><h2 className="sectiontitle">{editing?'แก้ไขเป้าหมาย':'สร้างเป้าหมายใหม่'}</h2><p className="sub">เลือกจำนวนเงินที่ต้องการและอัปเดตได้ทุกเมื่อ</p><form onSubmit={saveGoal}><div className="field"><label>ชื่อเป้าหมาย</label><input value={title} onChange={e=>setTitle(e.target.value)} maxLength={80} required /></div><div className="field"><label>เป้าหมายเงินเก็บ</label><div className="money">{money(target)}</div><input aria-label="เป้าหมายเงินเก็บ" type="range" min="0" max="1000000" step="1000" value={target} onChange={e=>setTarget(Number(e.target.value))}/><input aria-label="กรอกเป้าหมายเงินเก็บ" type="number" min="0" max="1000000" step="100" value={target} onChange={e=>setTarget(Math.max(0,Math.min(1000000,Number(e.target.value))))}/><div className="sub">0–1,000,000 บาท</div></div><div className="field"><label>เงินเก็บปัจจุบัน</label><div className="money">{money(current)}</div><input aria-label="เงินเก็บปัจจุบัน" type="range" min="0" max="1000000" step="1000" value={current} onChange={e=>setCurrent(Number(e.target.value))}/><input aria-label="กรอกเงินเก็บปัจจุบัน" type="number" min="0" max="1000000" step="100" value={current} onChange={e=>setCurrent(Math.max(0,Math.min(1000000,Number(e.target.value))))}/><div className="sub">0–1,000,000 บาท</div></div><div className="field"><label>เงินออมต่อเดือน</label><div className="money">{money(monthly)}</div><input aria-label="เงินออมต่อเดือน" type="range" min="0" max="100000" step="500" value={monthly} onChange={e=>setMonthly(Number(e.target.value))}/><input aria-label="กรอกเงินออมต่อเดือน" type="number" min="0" max="100000" step="100" value={monthly} onChange={e=>setMonthly(Math.max(0,Math.min(100000,Number(e.target.value))))}/><div className="sub">0–100,000 บาท</div></div><div className="actions"><button className="btn" disabled={busy} type="submit">{busy?'กำลังบันทึก…':editing?'บันทึกการแก้ไข':'บันทึกเป้าหมาย'}</button><button className="btn secondary" type="button" onClick={resetForm}>ล้างค่า</button></div></form>{message&&<div className={'notice '+(isError?'error':'success')}>{message}</div>}</section>
  <section className="card"><h2 className="sectiontitle">สรุปเป้าหมาย</h2><p className="sub">ตัวเลขอัปเดตตามข้อมูลที่กรอก</p><div className="field"><label>เป้าหมายทั้งหมด</label><div className="money">{money(target)}</div></div><div className="field"><label>ยังขาดอีก</label><div className="money" style={{color:remaining===0?'var(--green)':'var(--blue)'}}>{money(remaining)}</div></div><div className="field"><label>ความคืบหน้า</label><strong>{progress.toFixed(1)}%</strong><div className="progress"><div style={{width:progress+'%'}}/></div></div><div className="field"><label>ระยะเวลาโดยประมาณ</label><div className="money" style={{fontSize:25}}>{remaining===0?'ถึงเป้าหมายแล้ว':months===null?'ไม่สามารถคำนวณได้':`${months} เดือน`}</div><p className="sub">คำนวณโดยสมมติว่าออมเท่าเดิมทุกเดือน ไม่รวมดอกเบี้ย ผลตอบแทน หรือการถอนเงิน</p></div></section></div>
  <section className="card" style={{marginTop:18}}><div className="goalhead"><div><h2 className="sectiontitle">เป้าหมายที่บันทึกไว้</h2><p className="sub">บันทึก {goals.length} รายการในบัญชีนี้</p></div><button className="btn secondary" onClick={()=>void loadGoals()}>รีเฟรช</button></div>{loading?<div className="empty">กำลังโหลดข้อมูล…</div>:goals.length===0?<div className="empty">ยังไม่มีเป้าหมายที่บันทึก เริ่มจากสร้างเป้าหมายแรกของคุณได้เลย</div>:goals.map(g=>{const pct=g.target_amount>0?Math.min(100,g.current_amount/g.target_amount*100):100;const left=Math.max(0,g.target_amount-g.current_amount);return <div className="goalitem" key={g.id}><div className="goalhead"><div><h3>{g.title}</h3><p className="sub">เงินเก็บ {money(g.current_amount)} จาก {money(g.target_amount)}</p></div><span className="pill">{pct.toFixed(1)}%</span></div><div className="progress"><div style={{width:pct+'%'}}/></div><div className="sub">เหลืออีก {money(left)} · ออมต่อเดือน {money(g.monthly_saving)}</div><div className="actions" style={{marginTop:12}}><button className="btn secondary" onClick={()=>editGoal(g)}>แก้ไข</button><button className="btn danger" onClick={()=>void deleteGoal(g.id)}>ลบ</button></div></div>})}</section><p className="footer">ข้อมูลเป้าหมายนี้เป็นข้อมูลส่วนตัว โปรดใช้รหัสผ่านที่ปลอดภัยและออกจากระบบเมื่อใช้อุปกรณ์สาธารณะ</p></main>;
}
