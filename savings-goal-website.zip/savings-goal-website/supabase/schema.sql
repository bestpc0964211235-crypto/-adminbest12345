-- Run this script in Supabase SQL Editor before using the app.
-- Tables are protected by Row Level Security. Do not disable RLS in production.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.savings_goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 80),
  target_amount numeric(12,2) not null default 0 check (target_amount between 0 and 1000000),
  current_amount numeric(12,2) not null default 0 check (current_amount between 0 and 1000000),
  monthly_saving numeric(12,2) not null default 0 check (monthly_saving between 0 and 100000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  key text primary key check (char_length(key) between 1 and 80),
  value text not null default '',
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, role) values (new.id, 'member') on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.savings_goals enable row level security;
alter table public.site_settings enable row level security;

-- SECURITY DEFINER avoids recursive RLS when checking the admin role.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin');
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Members can read their own profile; admin status is checked by the protected function.
drop policy if exists "read own profile or admin" on public.profiles;
create policy "read own profile or admin" on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.is_admin()));
-- No client-side policy permits role updates. Set the first admin using the SQL below.

-- Each user can only read/write their own savings goals.
drop policy if exists "read own goals" on public.savings_goals;
create policy "read own goals" on public.savings_goals for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "insert own goals" on public.savings_goals;
create policy "insert own goals" on public.savings_goals for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "update own goals" on public.savings_goals;
create policy "update own goals" on public.savings_goals for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists "delete own goals" on public.savings_goals;
create policy "delete own goals" on public.savings_goals for delete to authenticated using (user_id = (select auth.uid()));

-- Only admins can manage website settings.
drop policy if exists "admin read settings" on public.site_settings;
create policy "admin read settings" on public.site_settings for select to authenticated using ((select public.is_admin()));
drop policy if exists "admin insert settings" on public.site_settings;
create policy "admin insert settings" on public.site_settings for insert to authenticated with check ((select public.is_admin()));
drop policy if exists "admin update settings" on public.site_settings;
create policy "admin update settings" on public.site_settings for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

-- IMPORTANT: After you create your own account, replace YOUR_ACCOUNT_EMAIL with your email and run:
-- update public.profiles p set role = 'admin'
-- from auth.users u where p.id = u.id and u.email = 'YOUR_ACCOUNT_EMAIL';
-- Do this only in the Supabase SQL Editor as the project owner. Never allow users to change their own role.
